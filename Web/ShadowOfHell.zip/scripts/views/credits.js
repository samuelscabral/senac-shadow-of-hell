class Credits extends GameElement {

    constructor() {
        super();
    }

    template() {
        return /*html*/ `
        `
    }
}
